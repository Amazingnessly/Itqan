#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-.}"

copy_file() {
  local src="$1"
  local dst="$2"
  mkdir -p "$(dirname "$ROOT/$dst")"
  cp "$src" "$ROOT/$dst"
}

BASE="$(cd "$(dirname "$0")/.." && pwd)"

copy_file "$BASE/src/learning/persistence.ts" "src/learning/persistence.ts"
copy_file "$BASE/src/learning/contentRepository.ts" "src/learning/contentRepository.ts"
copy_file "$BASE/src/learning/index.ts" "src/learning/index.ts"
copy_file "$BASE/src/pages/Lesson/LessonPage.tsx" "src/pages/Lesson/LessonPage.tsx"
copy_file "$BASE/src/app/routes.tsx" "src/app/routes.tsx"
copy_file "$BASE/src/app/App.tsx" "src/app/App.tsx"
copy_file "$BASE/src/components/path/PathNode.tsx" "src/components/path/PathNode.tsx"
copy_file "$BASE/src/pages/Path/PathPage.tsx" "src/pages/Path/PathPage.tsx"
copy_file "$BASE/scripts/activate-batch04-pilot.mjs" "scripts/activate-batch04-pilot.mjs"
copy_file "$BASE/scripts/validate-batch04-session.mjs" "scripts/validate-batch04-session.mjs"
copy_file "$BASE/scripts/validate-ui-no-arabic-content.mjs" "scripts/validate-ui-no-arabic-content.mjs"
copy_file "$BASE/docs/BATCH04_UI_INTEGRATION.md" "docs/BATCH04_UI_INTEGRATION.md"
copy_file "$BASE/README-BATCH04.md" "README-BATCH04.md"

MARKER="/* ===== Itqān Batch 04 — focused reading lesson ===== */"
if ! grep -Fq "$MARKER" "$ROOT/src/styles/global.css"; then
  cat "$BASE/styles_append.txt" >> "$ROOT/src/styles/global.css"
fi

echo "OK: Batch 04 files installed."
