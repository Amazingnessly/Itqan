# Installation Batch 04

Le ZIP contient son propre script d'installation afin d'éviter les modifications manuelles.

Depuis la racine du dépôt :

```bash
bash _batch04/scripts/install-batch04.sh .
node scripts/activate-batch04-pilot.mjs
```

Ensuite exécuter toutes les validations avant commit.
