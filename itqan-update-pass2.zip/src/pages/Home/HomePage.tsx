import { ArrowRight, Flame, Sparkles } from 'lucide-react'
import { Seal } from '../../components/ui/Seal'

export function HomePage({ onStart }: { onStart: () => void }) {
  return (
    <main className="page home-page">
      <header className="home-header">
        <div className="brand-lockup">
          <Seal size="md" />
          <div className="brand-copy">
            <div className="brand-name">Itqān</div>
            <div className="brand-tagline">Maîtrise chaque unité. Lis avec fluidité.</div>
          </div>
        </div>
        <div className="streak-pill" aria-label="Régularité : 4 jours">
          <Flame size={16} strokeWidth={1.8} />
          <strong>4</strong>
        </div>
      </header>

      <section className="home-editorial" aria-labelledby="mission-title">
        <div className="home-visual-wrap">
          <img
            className="home-visual"
            src="/illustrations/family-reference-temp.jpeg"
            alt="Scène familiale chaleureuse à table"
          />
          <div className="home-visual-badge" aria-hidden="true">
            <Sparkles size={14} strokeWidth={1.7} />
            <span>Une étape à la fois</span>
          </div>
        </div>

        <div className="mission-card">
          <span className="section-kicker">Mission du jour</span>
          <h1 id="mission-title">La précision d’abord.</h1>
          <p>Une courte session pour consolider un seul geste de lecture avant d’accélérer.</p>

          <div className="mission-meta" aria-label="Durée et objectif de la session">
            <span>Environ 6 min</span>
            <span>1 objectif</span>
          </div>

          <button className="primary-cta" type="button" onClick={onStart}>
            Commencer la session <ArrowRight size={18} strokeWidth={1.8} />
          </button>
        </div>
      </section>

      <section className="home-note" aria-label="Prochain cap">
        <span className="home-note__dot" aria-hidden="true" />
        <p><strong>Prochain cap</strong> Stabiliser la lecture avant d’augmenter le rythme.</p>
      </section>
    </main>
  )
}
