import { ChevronLeft, ShieldCheck, Target } from "lucide-react";
import { PathNode } from "../../components/path/PathNode";
import { loadLearnerState } from "../../learning/persistence";
import {
  CATEGORY_LABELS,
  LEVEL_LABELS,
  LEVEL_SYMBOLS,
  accuracyPercent,
} from "../../learning/progressInsights";
import type { ExerciseCategory } from "../../learning/types";

const stages: Array<{
  category: ExerciseCategory;
  x: number;
  y: number;
  labelSide: "left" | "right";
}> = [
  { category: "reading_units", x: 31, y: 58, labelSide: "right" },
  { category: "vowels_sukun", x: 67, y: 168, labelSide: "left" },
  { category: "shaddah", x: 37, y: 282, labelSide: "right" },
  { category: "article_al", x: 69, y: 398, labelSide: "left" },
  { category: "linking", x: 34, y: 516, labelSide: "right" },
  { category: "fluent_reading", x: 63, y: 632, labelSide: "left" },
];

export function PathPage({
  onBack,
  onStart,
}: {
  onBack: () => void;
  onStart: () => void;
}) {
  const learner = loadLearnerState();
  const currentSkill = learner.skills.reading_units;
  const currentAccuracy = accuracyPercent(learner, "reading_units");

  return (
    <main className="page path-page">
      <header className="path-header">
        <button
          className="icon-button"
          type="button"
          onClick={onBack}
          aria-label="Retour à l’accueil"
        >
          <ChevronLeft size={21} strokeWidth={1.8} />
        </button>
        <span className="section-kicker">Ton parcours</span>
        <h1>Construis une lecture sûre</h1>
        <p>Chaque étape demande une précision stable avant la suivante.</p>
      </header>

      <section className="path-mastery-card" aria-label="État de maîtrise">
        <div className="path-mastery-card__level">
          <span>{LEVEL_SYMBOLS[currentSkill.level]}</span>
          <div>
            <small>Niveau actuel</small>
            <strong>{LEVEL_LABELS[currentSkill.level]}</strong>
          </div>
        </div>
        <div className="path-mastery-card__metric">
          <small>Précision observée</small>
          <strong>
            {currentSkill.totalAttempts > 0 ? `${currentAccuracy} %` : "À établir"}
          </strong>
        </div>
      </section>

      <section className="path-status" aria-label="Statut du parcours">
        <div className="level-chip">
          <ShieldCheck size={14} />
          Précision avant vitesse
        </div>
        <div className="path-priority">
          <Target size={16} strokeWidth={1.8} />
          <span>{CATEGORY_LABELS.reading_units}</span>
        </div>
      </section>

      <section className="learning-journey" aria-label="Chemin d’apprentissage">
        <svg
          className="journey-line"
          viewBox="0 0 360 720"
          preserveAspectRatio="none"
          aria-hidden="true"
        >
          <path
            className="journey-line__base"
            d="M112 58 C252 100 280 132 241 168 C180 224 94 228 133 282 C184 352 282 330 248 398 C205 484 82 452 122 516 C171 595 255 580 227 632"
          />
        </svg>

        {stages.map((stage, index) => {
          const isPilot = stage.category === "reading_units";

          return (
            <PathNode
              key={stage.category}
              index={index + 1}
              title={CATEGORY_LABELS[stage.category]}
              state={isPilot ? "current" : "locked"}
              x={stage.x}
              y={stage.y}
              labelSide={stage.labelSide}
              onActivate={isPilot ? onStart : undefined}
            />
          );
        })}
      </section>
    </main>
  );
}
