#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-.}"
BASE="$(cd "$(dirname "$0")/.." && pwd)"

copy_file() {
  mkdir -p "$(dirname "$ROOT/$2")"
  cp "$BASE/$1" "$ROOT/$2"
}

copy_file "src/app/App.tsx" "src/app/App.tsx"
copy_file "src/pages/Home/HomePage.tsx" "src/pages/Home/HomePage.tsx"
copy_file "src/pages/Lesson/LessonPage.tsx" "src/pages/Lesson/LessonPage.tsx"
copy_file "src/pages/Path/PathPage.tsx" "src/pages/Path/PathPage.tsx"
copy_file "src/pages/Review/ReviewPage.tsx" "src/pages/Review/ReviewPage.tsx"
copy_file "src/pages/Profile/ProfilePage.tsx" "src/pages/Profile/ProfilePage.tsx"
copy_file "scripts/validate-batch06-no-arabic.mjs" "scripts/validate-batch06-no-arabic.mjs"
copy_file "scripts/validate-batch06-visual-contract.mjs" "scripts/validate-batch06-visual-contract.mjs"
copy_file "scripts/preview-itqan.sh" "scripts/preview-itqan.sh"
copy_file "docs/BATCH06_UX_REFINEMENT.md" "docs/BATCH06_UX_REFINEMENT.md"
copy_file "README-BATCH06.md" "README-BATCH06.md"

MARKER="/* ===== Itqān Batch 06 — visual rhythm & mobile polish ===== */"
if ! grep -Fq "$MARKER" "$ROOT/src/styles/global.css"; then
  cat "$BASE/styles_append.txt" >> "$ROOT/src/styles/global.css"
fi

GIT_MARKER="# Temporary Itqān install payloads"
if ! grep -Fq "$GIT_MARKER" "$ROOT/.gitignore"; then
  cat "$BASE/gitignore_append.txt" >> "$ROOT/.gitignore"
fi

chmod +x "$ROOT/scripts/preview-itqan.sh"

# Remove transient install payloads from earlier batches if present.
rm -rf "$ROOT/_batch04" "$ROOT/_batch05" "$ROOT/_batch06"

echo "OK: Batch 06 files installed and temporary batch folders cleaned."
